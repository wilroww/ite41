
const students = [
    {id: '1', name: 'John Doe', course: 'BSIT'},
    {id: '2', name: 'Jane Doe', course: 'BSIT'},
    {id: '3', name: 'Joseph Doe', course: 'BSCS'},
];

// // forEach 
// students.forEach((s) => {
//     console.log(s.name);
// });

// // find
// const johnDoe = students.find(s => s.name === 'John Doe');
// console.log(johnDoe);

// // filter 
// const bsitStudents = students.filter(s => s.course === 'BSIT');
// console.log(bsitStudents);

// // map
// const studentMap = students.map((s) => {return s.name.toUpperCase()});
// console.log(studentMap);

// // sort 
// const sortedStudents = studentMap.sort();
// console.log(sortedStudents);

// Constructors
// function Student(id, name, course) {
//     this.id = id;
//     this.name = name;
//     this.course = course;
// }

// // Classes
// const Person = class {
//     constructor(name) {
//         this.name = name;
//     }
// }

// const person = new Person('John Doe');
// console.log(person);

// class Student extends Person {
//     constructor(id, name, course) {
//         super(name);
//         this.id = id;
//         this.course = course;
//     }
// }

// const student = new Student('2', 'Jane Doe', 'BSIT');
// console.log(student);

// const url = 'https://abacus.jasoncameron.dev/hit/namespace/key';
// fetch(url);

// // ASync, Web API fetching
// const url = 'https://abacus.jasoncameron.dev/hit/namespace/key';
// fetch(url) 
//     .then (response => {
//         if(response.ok) {
//             return response.json()
//         }
//     })
//     .then (data => {
//         console.log(data.value);
//     })
//     .catch (error => console.error(error));

// // async...await
const url = 'https://abacus.jasoncameron.dev/hit/namespace/key';
async function displayResult() {
    let data = await fetch(url).then(async (response) => await response.json());
    console.log(data.value);
}

displayResult();

