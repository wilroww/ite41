// let name = 'John Doe';
// alert('Please input correct username or password');

// let anotherName = 'Jane Smith';
// console.log(anotherName); 

// const pi = 3.1416;
// pi = 1111;

// let answer = prompt("Do you wanna build a snowman?");
// console.log(answer);

// let result = confirm("Are you sure? ")
// console.log(result);

// let foo;
// console.log(foo);

// let bar = null;
// console.log(bar);

// const array = [1, 2, 3];
// array[2] = 5;
// console.log(array);
// array = [6, 7, 8];

// let firstName = 'John';
// let lastName = "Doe";
// console.log(firstName + " " + lastName);

// let myName = 'Jane Smith';
// console.log('Your name is ' + `${myName}`);

// let x = 5
// let y = "5"
// let z = 5
// console.log(x == y);
// console.log(x == z);
// console.log(x === y);
// console.log(x === z);

// console.log(x + z);
// console.log(x - z);
// console.log(x * z);
// console.log(x / z);
// console.log(x % z);

// if (x == y) {
//     console.log('x is equal to y')
// }

// if (x === y) {
//     console.log('x is equal to y')
// } else {
//     console.log('x is not equal to y')
// }

// let display = (x === y) ? console.log('x is equal to y') : console.log('x is not equal to y');

// let result = prompt("Enter a number: ")
// for(let i = 1; i <= result ; i++) {
//     console.log(i)
// }

// const names = ['Joan', 'Jane', 'John'];
// const newNames = new Array('Jake', 'Joe', 'Jason');
// newNames.push('Joan')
// newNames.unshift('Jane')


// names.forEach(name => {
//     console.log(name)
// });

// console.log('New Names')
// newNames.forEach(newName => {
//     console.log(newName)
// });

// console.log('Deleting New Names')
// let size = newNames.length
// for(let i = 1; i <= size; i++) {
//     let deletedName = newNames.pop();
//     console.log(deletedName);
// };

// for(let name of names) {
//     console.log(name);
// }

// let [name1, name2, name3] = names;
// console.log(name1);
// console.log(name2);
// console.log(name3);

// let [...nextNames] = names;
// nextNames.forEach(nextName => {
//     console.log(nextName);
// });

// const countries = new Array('Afghanistan');
// add at least 2 countries
// destructure the country array to new array 
// console log

// const person = {
//     'firstName': 'John',
//     'lastName': 'Doe'
// };

// console.log(person.firstName);
// console.log(person['lastName']);

// const name = new Object();
// name.age = 12;
// console.log(name.age);

// const student = {
//     'studentId': 'CT25-0001',
//     'name': 'John Doe',
//     'section': {
//         'code': 'IT501',
//         'course': 'BSIT'
//     }
// };

// let id = student.studentId;
// let newCourse = student.section.course;

// let {studentId, name} = student;
// console.log(studentId);
// console.log(name);

// let {code, course} = student.section;
// console.log(code);
// console.log(name);

// let newStudent = JSON.parse(student);

// let show = display();

// function display() {
//     console.log('this is a function');
// } 

/** function definition */
// let result = sum(4, 5);
// console.log(result);

// function sum(num1, num2) {
//     return num1 + num2;
// }

/** function object*/
// const sum = new Function('num1, num2', 'return num1 + num2');
// console.log(sum(3, 5));

/** function expresstion */
// const result = function sum(num1, num2) {
//     return num1 + num2;
// }

// console.log(result(5, 5));

/** anonymous function */
// const result = function (num1, num2) {
//     return num1 + num2;
// }

// console.log(result(5, 9));

/** function Constructor */
// function Person (name, address) {
//     this.name = name,
//     this.address = address
//     this.output = function () {
//         return this.name + ' from ' + this.address;
//     }
// }

// const john = new Person ('John Doe', 'Philippines');
// console.log(john.output());

/** arrow functions */
// const sum = (num1, num2) => num1 + num2;
// console.log(sum(1, 2));

// var global = '123';
// console.log(global);

// if(true) {
//     let local = '456';
//     console.log(global);
//     console.log(local);
// }

// console.log(local);

/** callback function in JavaScript is a function 
    that is passed as an argument to another function and is executed after some operation has completed */
// sum function is a callback function 
const sum = (num1, num2) => { return num1 + num2 }

// sumTest is a function that uses the definition of sum function 
const ave = (sumTest) => { return sumTest(1,2)/2 }

// sum function is passed as an argument
const getSum = ave(sum);
console.log(getSum);