//Use windows power shell: Start Process "chrome.exe" "--allow-file-access-from-files"
import data from './data/users.json' with { type: "json" };

const btnSubmit = document.getElementById('submit');
const username = document.getElementById('username');
const passwd = document.getElementById('password');

btnSubmit.addEventListener('click', () => {
	let user = data.find((result) => result.username === username.value);
	if(user == undefined) {
		alert('Invalid username');
		return;
	}
	if(user.password !== passwd.value) {
		alert('Wrong password');		
	} else {
		window.location.href = 'home.html';				
	}
});
