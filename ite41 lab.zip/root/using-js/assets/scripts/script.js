// console.log(document);

// // Selection methods
// console.log(document.getElementById('username'));
// console.log(document.getElementsByClassName('form-div'));
// console.log(document.getElementsByName('title'));
// console.log(document.getElementsByTagName('div'));

// // Node Object Properties
// const node = document.querySelector('.form').firstElementChild;
// console.log(node);
// const nextNode = node.nextElementSibling;
// console.log(nextNode);

// // Query Selectors
// const passwordElement = document.querySelector('#password');
// console.log(passwordElement);
// console.log(document.querySelector('.form'));
// console.log(document.querySelectorAll('.form-div'));
// console.log(document.querySelector('.form h1'));

// // Node Properties
// let title = document.querySelector('.form h1');
// console.log(title.className);
// title.textContent = 'Log in';

// // Changing Element Style
// let title = document.querySelector('.form h1');
// title.style.color = 'red';

// Using innerHTML
// title.innerHTML = "TEST";

// // Using textContent
// title.textContent = "TEST 2";

// // DOM Manipulation
// const username = document.getElementsByClassName('form-div')[0];
// const text = document.createTextNode('Invalid input');
// const label = document.createElement('label');
// label.id='error';
// label.appendChild(text);
// username.appendChild(label);
// console.log(username);

// // Event Definition
// function submit (e) {
//     console.log('Button is clicked');
//     console.log(e.target.name);
// }

// const submitButton = document.querySelector('.form-button');
// submitButton.addEventListener('click', submit);

// Event Types
// submitButton.addEventListener('mouseover', () => {
//     submitButton.style.color = 'yellow';
// });
// submitButton.addEventListener('mouseout', () => {
//     submitButton.style.color = 'white';
// });

// // Input Validation 
// const username = document.getElementsByClassName('form-div')[0];
// const usernameInput = document.getElementById('username');
// const submitButton = document.querySelector('.form-button');
// function submit() { 
//     if(usernameInput.value === '') {
//         const text = document.createTextNode('Invalid input');
//         const label = document.createElement('label');
//         label.id='error';
//         label.appendChild(text);
//         username.appendChild(label);
//         console.log(username);
//     }
// }
// submitButton.addEventListener('click', submit);


// // RegExp
// let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
// const username = document.getElementsByClassName('form-div')[0];
// const usernameInput = document.getElementById('username');
// const submitButton = document.querySelector('.form-button');
// function submit() {
//     if(!emailPattern.test(usernameInput.value)) {
//         const text = document.createTextNode('Invalid email');
//         const label = document.createElement('label');
//         label.id='error';
//         label.appendChild(text);
//         username.appendChild(label);
//     } else {
//         alert('Credentials are valid!');
//     }
// }
// submitButton.addEventListener('click', submit);